import os
import logging
import boto3

from ecs_ami_updater import Updater
from asg import ASG
from ecs import ECS

logger = logging.getLogger()
logger.setLevel(logging.INFO)

client = boto3.client('lambda')
client.get_account_settings()

def lambda_handler(event, context):
    updater = Updater()
    updater.ecs = ECS(updater.args.cluster, updater.boto_session, updater.boto_config)
    for asg_name in updater.ecs.cluster_asgs:
        updater.asg = ASG(asg_name, updater.boto_session, updater.boto_config)
        updater.logger.info(f"found AMI for {asg_name}: {updater.asg.latest_ami}")
        if updater.asg.lt_curr_ami == updater.asg.latest_ami:
            updater.logger.info(f'ami for {asg_name} is up to date')
        else:
            updater.logger.info(f'found newer AMI for {asg_name} ({updater.asg.latest_ami}), updating launch template')
            updater.asg.update_launch_template()
            updater.asg.set_launch_template_version()

        updater.logger.info(f'rolling instances in the {updater.args.cluster} ECS cluster')
        updater.roll_instances(asg_name, updater.args.cluster)
        updater.logger.info('all instances have been replaced')

    return 'ECS EC2 udpate successfull'
